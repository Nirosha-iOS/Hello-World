//
//  ViewController.swift
//  UltraSound
//
//  Created by Nirosha S on 17/05/19.
//  Copyright © 2019 Nirosha S. All rights reserved.
//

import UIKit

class ViewController: UIViewController,StimshopDelegate {
    
    func didDetectWav(withCode code: String!) {
    
    }
    
    func didStopWithErrorMessage(_ message: String!) {
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        StimshopSDK.sharedInstance()?.delegate = self
        StimshopSDK.sharedInstance()?.takeOff(withAPIKey: "")
        // Do any additional setup after loading the view, typically from a nib.
    }


}

