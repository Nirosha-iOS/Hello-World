//
//  CategoryCollectionView.swift
//  NewApp
//
//  Created by Nirosha S on 16/03/19.
//  Copyright © 2019 Nirosha S. All rights reserved.
//

import UIKit

class CategoryCollectionView: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{

    @IBOutlet weak var btnList:UIButton?
    @IBOutlet weak var btnSort:UIButton?
    @IBOutlet weak var btnFilter:UIButton?
    @IBOutlet weak var categoryCollection:UICollectionView?
    var arrayCategoryList:NSMutableArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnList?.tag = 1
        // Do any additional setup after loading the view.
    }
    
    @IBAction func fnClickListGridView(sender:UIButton){
        
        if(sender.tag == 1) {
            
            sender.tag = 10
            sender.setImage(UIImage(named: "group"), for: .normal)
            
        }else  {
            
            sender.tag = 1
            sender.setImage(UIImage(named: "list"), for: .normal)
            
        }
        
        categoryCollection?.reloadData()
    }

    //MARK: Collection View Delegate
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
       
            return arrayCategoryList.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
     
            
        let cell:CategoryCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCollectionViewCell", for: indexPath) as! CategoryCollectionViewCell
            
           
            
            return cell
            
       
        
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if(btnList?.tag == 1) {
            
            return CGSize(width: (collectionView.frame.size.width-40), height: 100)
            //
        }else {
            
            return CGSize(width: ((collectionView.frame.size.width-60)/2), height: 250)
        }
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
         return UIEdgeInsets(top: 20.0, left: 20.0, bottom: 20.0, right: 20.0)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    {
        return 20
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
    

}
