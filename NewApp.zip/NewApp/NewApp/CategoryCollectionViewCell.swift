//
//  CategoryCollectionViewCell.swift
//  NewApp
//
//  Created by Nirosha S on 16/03/19.
//  Copyright © 2019 Nirosha S. All rights reserved.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblName:UILabel?
    @IBOutlet weak var lblPrice:UILabel?
    @IBOutlet weak var lblSpecial:UILabel?
    @IBOutlet weak var imgProduct:UIImageView?
    @IBOutlet weak var btnFav:UIButton?
    @IBOutlet weak var btnCard:UIButton?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
